//
//  ViewController.swift
//  Picker
//
//  Created by Saurabh Gupta on 8/3/17.
//  Copyright © 2017 Saurabh Gupta. All rights reserved.
//

import UIKit

class PickerViewController: UIViewController {

    @IBOutlet weak var pickerOneTextField: ApplicationTextField! {
        didSet {
            pickerOneTextField.backgroundColor = .clear
            pickerOneTextField.textAlignment = .center
            pickerOneTextField.font = UIFont.systemFont(ofSize: 24.0)
            pickerOneTextField.text = "Select picker 1 value"
            pickerOneTextField.pickerType = .Integer
        }
    }
    
    @IBOutlet weak var pickerTwoTextField: ApplicationTextField! {
        didSet {
            pickerTwoTextField.backgroundColor = .clear
            pickerTwoTextField.textAlignment = .center
            pickerTwoTextField.font = UIFont.systemFont(ofSize: 24.0)
            pickerTwoTextField.text = "Select picker 2 value"
            pickerTwoTextField.pickerType = .Decimal
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

}

