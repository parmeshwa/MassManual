//
//  ApplicationTextField.swift
//  Picker
//
//  Created by Saurabh Gupta on 8/3/17.
//  Copyright © 2017 Saurabh Gupta. All rights reserved.
//

import UIKit

class ApplicationTextField: UITextField {
    
    var selectedAnswer = ""
    var decimalValue = "0"
    var integerValue = "1"
    
    enum PickerType {
        case Integer
        case Decimal
        
        case None
    }
    
    var pickerType = PickerType.None {
        didSet {
            switch pickerType {
            case .Integer, .Decimal:
                inputView = picker()
                inputAccessoryView = inputAccessoryView()
            case .None:
                inputView = nil
            }
        }
    }
    
    private func picker() -> UIPickerView {
        let picker = UIPickerView()
        picker.showsSelectionIndicator = true

        switch pickerType {
        case .Integer:
            picker.backgroundColor = .white
        case .Decimal:
            picker.backgroundColor = .black
        default:
            break
        }
        
        picker.dataSource = self
        picker.delegate = self
        
        return picker
    }
    
    
    private func inputAccessoryView() -> UIView {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 44))
        switch pickerType {
        case .Integer:
            view.backgroundColor = .white
        case .Decimal:
            view.backgroundColor = .black
        default:
            break
        }
        
        let doneButton = buttonWithTitle(title: "Done", action: #selector(doneButtonTapped))
        doneButton.sizeToFit()
        doneButton.frame = CGRect(x: view.frame.width - doneButton.frame.width - 10, y: 0, width: doneButton.frame.width, height: 44)
        
        let clearButton = buttonWithTitle(title: "Clear", action: #selector(clearButtonTapped))
        clearButton.sizeToFit()
        clearButton.frame = CGRect(x: ((view.frame.width/2) - 22), y: 0, width: clearButton.frame.width, height: 44)
        
        let cancelButton = buttonWithTitle(title: "Cancel", action: #selector(cancelButtonTapped))
        cancelButton.sizeToFit()
        cancelButton.frame = CGRect(x: 10, y: 0, width: cancelButton.frame.width, height: 44)
        
        view.addSubview(doneButton)
        view.addSubview(clearButton)
        view.addSubview(cancelButton)
        
        return view
    }
    
    private func buttonWithTitle(title: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        switch pickerType {
        case .Integer:
            button.setAttributedTitle(NSAttributedString(string: title, attributes: [NSForegroundColorAttributeName : UIColor.black, NSFontAttributeName : UIFont.systemFont(ofSize: 16.0)]), for: .normal)
        case .Decimal:
            button.setAttributedTitle(NSAttributedString(string: title, attributes: [NSForegroundColorAttributeName : UIColor.white, NSFontAttributeName : UIFont.systemFont(ofSize: 16.0)]), for: .normal)
        default:
            break
        }
        
        button.addTarget(self, action: action, for: .touchUpInside)
        
        return button
    }
    
    func doneButtonTapped() {
        switch pickerType {
        case .Integer:
            text = selectedAnswer.uppercased() == "" ? integerValue : selectedAnswer
        case .Decimal:
            text = selectedAnswer.uppercased() == "" ? integerValue + "." + decimalValue : selectedAnswer
        default:
            break
        }
        resignFirstResponder()
    }
    
    func cancelButtonTapped() {
        selectedAnswer = text ?? ""
        resignFirstResponder()
    }
    
    func clearButtonTapped() {
        switch pickerType {
        case .Integer:
            text = "Select picker 1 value"
        case .Decimal:
            text = "Select picker 2 value"
        default:
            break
        }
        resignFirstResponder()
    }
}

extension ApplicationTextField: UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        switch pickerType {
        case .Integer:
            return NSAttributedString(string: "\(row + 1)", attributes: [NSForegroundColorAttributeName:UIColor.black])
        case .Decimal:
            if component == 0 {
                return NSAttributedString(string: "\(row + 1)", attributes: [NSForegroundColorAttributeName:UIColor.white])
            } else {
                return NSAttributedString(string: "." + "\(row)", attributes: [NSForegroundColorAttributeName:UIColor.white])
            }
        default:
            return nil
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch pickerType {
        case .Integer:
            selectedAnswer = "\(row + 1)"
        case .Decimal:
            if component == 0 {
                selectedAnswer = "\(row + 1)" + "." + decimalValue
                integerValue = "\(row + 1)"
            } else {
                selectedAnswer  =  integerValue + "." + "\(row)"
                decimalValue = "\(row)"
            }
        case .None:
            break
        }
    }
}

extension ApplicationTextField: UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        switch pickerType {
        case .Integer:
            return 1
        case .Decimal:
            return 2
        default:
            return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            return 500
        } else {
            return 10
        }
    }
}

